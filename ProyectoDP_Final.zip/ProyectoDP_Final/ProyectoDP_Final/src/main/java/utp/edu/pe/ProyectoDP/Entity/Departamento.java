package utp.edu.pe.ProyectoDP.Entity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class Departamento {

    private int idDepartamento;
    private String nombreDepartamento;
}
